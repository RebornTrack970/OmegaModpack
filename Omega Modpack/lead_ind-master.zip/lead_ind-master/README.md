Hello! You are on the page of our mod!
here you will find:
* .json files from mod
* interesting sprites
* And - oh Lord! The mod itself! can you imagine?
Installation:
* Open "mods" in game
* Open "import from GitHub"
* Write it:
 PetruCHIOrus/lead_ind
* Wait...
* Is that all? It was easy, right?<br/>
trello https://trello.com/b/8k0ygSAf/lead-ind-trello
----------------------------------
Здравствуйте!  Вы находитесь на странице нашего мода!
здесь вы найдете:
* .json файлы мода
* Интересные спрайты
* И - о Боже!  Сам мод!  Вы можете себе это представить?
 Установка:
* Откройте "mods" в игре
* Сделайте "import from GitHub"
* Напишите: PetruCHIOrus/lead_ind
* Подождите...
* И это всё?  Это было легко, правда?<br/>
trello https://trello.com/b/8k0ygSAf/lead-ind-trello
