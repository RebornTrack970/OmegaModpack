![logo](preview.png)

Also check out [routorio](https://github.com/DeltaNedas/routorio)

# V6 - WINTER UPDATE
## Additions
#### Snowballs!
* Mine snow or ice snow to get them. Use as ammo in Shredder and a little bit more!
#### Freezer!
* Make snowballs from water
#### Heater!
* Melt snowballs back into water
#### Buildable scrap walls
#### Scraper
* Small drill made out of scrap.
#### Shredder
* Small turret made out of scrap. Immersive firerate and inaccuracy.
#### Sieve
* Processes sand and outputs scrap.
#### Filter
* Cleans polluted water and outputs thorium.
#### Tainter
* Taints water using spore pods.
#### Thorns
* Damage all units walking on them.
#### reWall
* Self-regenerating Wall, comes in 2 sizes
