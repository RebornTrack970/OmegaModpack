[![HAI-Banner-Ex2.png](https://i.postimg.cc/K8Bhqb5x/HAI-Banner-Ex2.png)](https://postimg.cc/nXFWr65P)
# Heavy Armaments Industries
Merged from Heavy Armaments and Heavy Industries forming a mod that expands vanilla mindustry both arsenals and industrial aspect to offer more selection with more powerful and efficient turrets and factory

## Software Used
- **Inkscape** (For logo)
- **Visual Studio Code** (Editing JSON)
- **Piskel** (Making Sprites)


