# Braindustry-Mod
Huge Mindustry modification which expands end-game content and adds many new useful things.

**Stable Version - 1.4.1**

**Newest Alpha/Beta version - 1.4.2 build 2**

**Minimal Mindustry Build - 121**

**[YouTube](https://www.youtube.com/channel/UCIN35lW7fC3tXcNDd-Ip7Pw?view_as=subscriber)**

**[VK Group](https://vk.com/braindustry)**

**[Discord](https://discord.gg/Q2qdHE2t)**

![alt tag](https://sun9-41.userapi.com/impg/jB_FylhwINfHEw0vyA3suZ-oQTxWgCLO3AIoWA/19iB70aAoKc.jpg?size=1280x713&quality=96&sign=9e91344d66d56150149c768012735f1c "Screenshot")​
![alt tag](https://user-images.githubusercontent.com/63517945/101539745-0f616300-39b0-11eb-99ec-5c2fc6d75d80.png "Screenshot")​
