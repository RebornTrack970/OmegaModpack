This mod adds:

-Drills.

-Plants.

-Conveyors.

-Reactors and solar panels.

-Accumulators

-Containers

-As well as basic routing items.

On cooperation issues write in private:
-https://vk.com/mindofmagic
