# Colloseus-Mod
Modification for Mindustry game. Adds new items, liquids, fabrics, turrets, mechanics, maps and weathers.

All turrets and units are divided into factions. There are 6 fractions in total. 
This mod is entirely made up of scripts. The scripts and nothing more. Enjoy. 

Modification development is forever stopped. 

**Min game version - 121**

**Current mod version - 1.2.1**

![Logo](sprites-override/ui/logo.png)

## Mod Screenshots

![alt tag](https://sun9-32.userapi.com/impg/B3FzPuhh-G32vI4DtDAqZHV53osAK5ljFNaeeQ/QBGrnTRUII8.jpg?size=1080x882&quality=96&proxy=1&sign=2298276508da899aa9f81a7aa499e9be "Clash of two factions")

![alt tag](https://sun9-15.userapi.com/impg/KwxgSTroImspVcXpcGD45iNPoqy5J0xF-RoYlw/y_P-LQLRv-8.jpg?size=1080x480&quality=96&proxy=1&sign=3c955e22117cf4ff52a725a1a83b2602 "The largest unit in modification - leviathan")


