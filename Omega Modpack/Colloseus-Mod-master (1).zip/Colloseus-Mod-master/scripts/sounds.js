const F = require("func");
const SO = this.global.SOUNDS;

SO.pulse = loadSound("pulse2");
SO.beamShoot = loadSound("beamShoot");
SO.mixedLaserShoot = loadSound("mixedLaserShoot");
SO.movingLaser = loadSound("movingLaser");
SO.beamLaser = loadSound("beamLaser");
SO.bigLaserShoot = loadSound("bigLaserShoot");