# ChaosArranity
A mod that adds a few items and liquids, and a whole new tier of upgrades, along with arc. Made by Chickenloser and Oreo. 

Adds 75 new blocks, 3 items, 2 liquids, and 18 units, with plans to add even more.

# Credits
Ideas and JSON by Oreo

Sprites and JSON by CoinCaribou2070/Chickenloser

Sprites made by Duvent

Special Thanks to Skared Kat

# Extras
Join our Discord to report bugs, be notified of updates, or make suggestions.

discord.gg/6y6HAqTrkJ
