# Larger Cores
 Adds Tier 4 and Tier 5 Cores
