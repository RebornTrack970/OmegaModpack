const multiCultivator = extendContent(GenericCrafter,"multi-cultivator",{});
multiCultivator.drawer = new DrawAnimation();
