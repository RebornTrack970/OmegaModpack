const titaniumLaunchPad = extend(LaunchPad, "titaniumlaunchpad", {});
titaniumLaunchPad.alwaysUnlocked = true;
