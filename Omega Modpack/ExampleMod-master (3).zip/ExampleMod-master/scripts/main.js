
//blocks
require("blocks/activationmatter-weaver");
require("blocks/atmospheric-cooler");
require("blocks/impact-projector");
require("blocks/multi-projector");
require("blocks/multi-cultivator");
require("blocks/power-processor");
require("blocks/coredvalut");
require("blocks/boostwater");
require("blocks/plastsalvo");
require("blocks/titanium-launch-pad")

//experiement
require("experiment/page");
require("experiment/oregen");

require("campaign/planet");

//units
require("units/testunit4");

print("Load Complete!");






/*
credit(){
  younggam: "answering tons of question",
  deltaNedas: "refer to routorio, rtfm",
  sk7725: "answering tons of question, refer to testers"
}
*/
