The lore (In order of events)

Stone
Surprisingly, each universe incarnation might be different from the last one in not just it's formation, but it's rules. Apparently in this iteration, radioactive materials take an extremely short time to react as processes down at the quantum level are sped up. How do we know this? The last iteration had left behind indestructible information before it was reborn. Information on how nuclear reactions worked. There was one exception that exists however. In the stone of planets, there remains a glowing property. Radioactive materiels in the stone of each planet decaying extremely slowly. We are able to see at night because of this. It emits enough light to dimly light up the surface of many planets. The light is on the lower end of the spectrum, still on the visible portion making it usable for a light source deep in space. This was normal to us. The glowing stone was a blessing to have and we valued it until we found better ways of lighting up our encampments.

Templura 

Taconite Pulveriser:
During the volitile stage of the universe, Templura and Serpulo, fated to meet, crashed into eachother with such force, the shockwave blew away the other planets in the system. The remains of Templura formed a small rocky planet while Sepulo, barely held together after the impact slowly reformed into a new world. Now it's ours. Come, our work is not done yet.

Ioniser:
However, there was a small problem with the formation of the planets. Held together by nothing but gravity, Templura's surface was jagged, unlike other planets which looked rounded, almost perfectly spherical.

Sand Reversal Unit:
Serpulo's surface was cooling down. It had a magnetic field caused by the swirling of molten metal at the planet's core, protecting gasses from intense solar winds. However, as there was high volcanic activity, the surface never formed an ocean. There were isolated pockets of water on it but no grand seas for sailors to explore.

life

Catapult:
Life on Serpulo was harsh after the inccident of the first mass extinction. Nothing could survive. Or so we thought.

Trebuche:
There was life flourishing in the pockets of water scattered throughout Sepulo. They had adapted to the harsh circumstances, growing metallic scales.

Cannon:
Eventualy, after a few hundred years or so, life adapted to the surface's conditions. Not biological life, but mechanical life.

Howitzer:
Mechs which resembled inscects, fish, birds and more were formed.

war
Core Beacon
Years ago, a great flood overwhelmed Serpulo and rusted the grounds. Some 1000 years later, when they returned, a great discovery was made.

Rusty Core
The predecessor of an old core was found and quickly scanned for it's structural integrity. blueprints were recovered from it, revealing the history of Sepulo's environment. 

Rusty Alpha:
After it was found, the slag wars began. Sepulo was going through a period of increased volcanic activity due to weak spots leftover from the planet's formation.

Rusty Delta:
Some went rogue. Others tried to help their relatives survive. In the end, it didn't matter though. The only places safe were now the ever increasing amount of caves.

slag

Volitile generator:
When they first discovered scrap, they didn't know what to think. One suggested that something happened, though the others dismissed the idea as blasphemy. 

Coal compresser:
Eventualy the bots had found out that it had many metals in it, even the valued thorium that kept their reactors fueled. For now, they tried to figure out how to extract the metals directly. Nothing they tried worked.  One of the bots decided to melt the scrap. They said that the idea was pointless, as these were ancient fossils which they were studying. The bot's name was dart. They were banished to the farlands and told never to come back again, with threats to be shot on sight.

Dunescape crags

Lava cannels run underground
A smell of char lingers...
The diralect used a superweapon here
The usage of it brought downfall to their conquest to concour the planet
now all that remains is their tech
