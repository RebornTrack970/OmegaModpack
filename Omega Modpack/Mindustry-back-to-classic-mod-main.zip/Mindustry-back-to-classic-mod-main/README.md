# Mindustry back to classic BETA
This mod adds previously removed items to the game
![logo.png](logo.png)
