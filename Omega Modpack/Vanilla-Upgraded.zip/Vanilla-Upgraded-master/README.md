![Logo](sprites-override/ui/logo.png) 

[![Discord](https://img.shields.io/discord/730535373306069114)](https://discord.gg/TQpdDKn)
[![GPLv3 License](https://img.shields.io/badge/License-GPL%20v3-yellow.svg)](LICENSE)

_[Trello Board](https://trello.com/b/kT6zadVS/vanilla-upgraded-trello)_
<br>_[Wiki](https://voz8duh.wixsite.com/vanilla-upgraded)_ 

# Vanilla-Upgraded
A mod that adds a lot more experience for the games!
<br>I just hope you enjoy the mod ^^

U can join the official discord server of Vanilla-Upgraded now with this [link](https://discord.gg/TQpdDKn)!

## The mod add: 
`Items`: 9
<br>`Blocks`: 85
<br>`Turrets`: 20
<br>`Mechs`: 7
<br>`Liquids`: 2
<br>`Units`: 16
<br>`Maps`: 6

### Contributing

See who [contributes](CONTRIBUTING.md) to the mod.

### Bundle 
English bundle have arrived! 
<br>Russian bundle is here! 
<br>Spanish bundle is here! 
<br>Polish bundle is here!
<br>We plan to add bundles based on player requests. 
