Co-Developers: `VozDuh`, `Summet#4530` and `Pekka Angelo#1608`

External:
<br>Designer: `Valoche3000` and `Alexender`
<br>Mapper: `Zerox` and `Neutron`
<br>Development aid: `Senri` and `Alexender`
