# bigger-display
14 and 16 tile displays for mindustry
![two displays side by side, frameless first, then framed](/preview.png?raw=true "two displays side by side, frameless first, then framed")