# Gravillaso V0.9.4
Gravillaso - mod based on magnetic materials 
PS: Due to the pile of generation in 6.0, new ores cannot be added
Adds
* Materials[3]
* Liquids[0]
* Drills [1]
* Conveyors[2]
* Turrets [3]
* Walls [1-Type]
* Factory[3]
* OtherBlock[2]  
[Vkontakte](https://vk.com/nickname_73)  
