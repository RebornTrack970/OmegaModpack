# Cobalt Mod
(Currently WIP) A mindustry mod that aims to add more unique turrets and itens.

# Content

 Currently only adds 10 turrets but in the future will have a new material and maybe some support blocks.

# Future changes

 - Some sprite changes;
 
 - New materials;
 
