# Exotic Mod
We got together over Discord to bring you this interesting and overpowered mod. We hope you enjoy it!
Exotic is progressing to alpha, BlueWolf has FINALLY completed adding most blocks, and units are up next on the bucket list. 

Current changes: interlude, with resprites.
