const voidron = extend(AttributeSmelter, "voidron-collider", {});
// voidron.canPlaceOn(Blocks.space, Team.derelict);
