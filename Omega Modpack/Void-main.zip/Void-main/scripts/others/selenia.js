const selenia = extend(Planet, "selenia", Planets.sun, 1, 1, {});
