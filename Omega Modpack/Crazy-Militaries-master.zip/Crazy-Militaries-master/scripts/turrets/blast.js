const blast = extendContent(ItemTurret, "blast", {});
/*blast.buildType = () => extend(ItemTurret.ItemTurretBuild, {
  shouldTurn(){
    return false;
  }
})*/