require('turrets/blast');
require('turrets/inferno');
require('units/former');
print('whoever reads this, enjoy Crazy Militaries! :d');