---
name: Bug report
about: Report a bug
title: ''
labels: bug
assignees: ''

---

**Platform**:
Debian sid amd64

**Mindustry Version**:
stable 105

**Routorio Version**: *the number please*
"latest"

**Describe the issue**:
routorio have router

**Steps to reproduce, including save file if non trivial**
1. routorio
2. router!

**(Crash) logs, if relevant**
no
