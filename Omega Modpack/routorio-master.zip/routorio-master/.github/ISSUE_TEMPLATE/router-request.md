---
name: Router request
about: Suggest a new router
title: router
labels: router
assignees: ''

---

**Name**:
Rout from Rout and Sorty

**Description/Background**:
Crazy scientist router that is also addicted to ketamine router

**Mechanics**:
Sometimes turn himself into pickle router
