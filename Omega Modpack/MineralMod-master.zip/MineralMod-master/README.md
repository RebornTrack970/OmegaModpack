# MineralMod 
This mod will allow you to immerse yourself in the world of minerals and mechanisms. 
This mod adds:

-Drills.

-Plants.

-Conveyors.

-Reactors and solar panels. 

-Accumulators

-Containers

-As well as basic routing items.

On cooperation issues write in private messages in vk: 
https://vk.com/theskyfather
Later I'll add a tree of research...
