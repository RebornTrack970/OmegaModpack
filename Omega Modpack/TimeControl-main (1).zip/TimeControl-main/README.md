# TimeControl
Speeds up or slows down Mindustry.   

Supports `x0.25` ~ `x16`. Some buttons can be pressed twice to alternate between different modes.   
Press & hold `x1` to fold/unfold the buttons.   

Not intended for multiplayer use.   
