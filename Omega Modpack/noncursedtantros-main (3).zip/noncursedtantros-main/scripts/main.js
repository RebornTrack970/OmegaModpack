

require("campaign/planet");

print("Load Complete!");






/*
credit(){
  younggam: "answering tons of question",
  deltaNedas: "refer to routorio, rtfm",
  sk7725: "answering tons of question, refer to testers"
}
*/
