const bitLib = this.global.pm.bitTurretLib;

const bit = bitLib.new8BitTurret("pixel", 8, PowerTurret, PowerTurret.PowerTurretBuild);