# Progressed Materials
Adds a bunch of scripted stuff. The name definitely made up of synonyms of "Advance" and "Content."

## Content
### Mindron Collider:
A creatively named particle collider that fuses Techtanite.
### Techtaninte:
An advanced alloy used for building high teir Progressed things.
### Eruptor:
Erupts lava from the floor, setting things on fire and dealing massive damage.
### Minigun:
Longer they fire, faster they fire.
### Tesla:
Not your average arc. Brings the shock directly to the enemy!
### Kugelblitz:
**s u c c**
### Chaos Array:
https://www.reddit.com/r/Mindustry/comments/iyelg3/the_true_power_of_the_duo
