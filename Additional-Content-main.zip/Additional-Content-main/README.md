Great amounts of content are added by this mod.
A variety of blocks, units and items are given by this mod.
Have fun playing around!
Discord Server: https://discord.gg/J7EqmJrH
Currently in early stage.
