const irel = extendContent(mech, "irel", {});
irule.constructor = function(){
  return extend(PayloadUnit, {});
};
irule.abilities.add(new ShieldRegenFieldAbility(8, 120, 100, 7));